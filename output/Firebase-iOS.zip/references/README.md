# Firebase Open Source Docs
Firebase Open Source Docs is a monorepo that contains
all Firebase written documentation that accepts community
contributions. This includes Firebase product documentation
or codelab steps.
