# GitHub Issues

Recent issues from the repository (84 total).

## Open Issues (0)


## Recently Closed Issues (84)

### #121: 私有库，依赖SmartCodable， 打包xcframework，会有命名空间冲突
**Labels:** No labels | **Closed:** 2025-12-18
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/121)

### #126: @IgnoredKey看起来会影响到@SmartFlat解析
**Labels:** No labels | **Closed:** 2025-12-18
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/126)

### #125: 泛型和基础类型的支持
**Labels:** No labels | **Closed:** 2025-12-11
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/125)

### #123: 请问是否支持actor？
**Labels:** No labels | **Closed:** 2025-12-11
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/123)

### #124: 基础配置设置
**Labels:** No labels | **Closed:** 2025-11-26
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/124)

### #120: 无法与swiftlint兼容
**Labels:** No labels | **Closed:** 2025-11-26
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/120)

### #122: 无法使用@SmartSubclass宏
**Labels:** No labels | **Closed:** 2025-11-12
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/122)

### #116: 多行字符因缩进导致解析失败
**Labels:** No labels | **Closed:** 2025-10-13
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/116)

### #118: 键映射转换处理方式请教
**Labels:** No labels | **Closed:** 2025-10-13
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/118)

### #117: 枚举返回没有定义的  转model解析失败，这种如何处理呀
**Labels:** No labels | **Closed:** 2025-10-11
[View on GitHub](https://github.com/iAmMccc/SmartCodable/issues/117)

